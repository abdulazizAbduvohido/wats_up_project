import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ContactEditWidget extends StatefulWidget {
  final String currentContactName;
  final String currentContactPhoto;
  final Function(String, String) onSave; // Saqlash uchun callback

  const ContactEditWidget({
    Key? key,
    required this.currentContactName,
    required this.currentContactPhoto,
    required this.onSave,
  }) : super(key: key);

  @override
  _ContactEditWidgetState createState() => _ContactEditWidgetState();
}

class _ContactEditWidgetState extends State<ContactEditWidget> {
  late TextEditingController _nameController;
  String? _newPhoto;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.currentContactName);
    _newPhoto = widget.currentContactPhoto;
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _newPhoto = pickedFile.path;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Edit Contact'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              backgroundImage: _newPhoto != null ? AssetImage(_newPhoto!) : AssetImage(widget.currentContactPhoto),
              radius: 50,
              onBackgroundImageError: (exception, stackTrace) {
                print('Dialog rasmi yuklanmadi: $exception');
              },
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _pickImage,
              child: const Text('Change Photo'),
            ),
            const SizedBox(height: 10),
            TextField(
              decoration: const InputDecoration(labelText: 'Additional Info (e.g., phone)'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            widget.onSave(_nameController.text, _newPhoto ?? widget.currentContactPhoto);
            Navigator.pop(context);
          },
          child: const Text('Save'),
        ),
      ],
    );
  }
}