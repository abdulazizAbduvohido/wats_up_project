import 'package:flutter/material.dart';

class MessageInput extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSend;
  final VoidCallback onPickImage;

  const MessageInput({
    required this.controller,
    required this.onSend,
    required this.onPickImage,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[200],
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.photo, color: Colors.green),
            onPressed: onPickImage,
          ),
          Expanded(
            child: TextField(
              controller: controller,
              decoration: const InputDecoration.collapsed(
                hintText: "Xabar yozing…",
                hintStyle: TextStyle(color: Colors.black54),
              ),
              style: const TextStyle(color:  Colors.black),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.send, color: Colors.green),
            onPressed: onSend,
          ),
        ],
      ),
    );
  }
}