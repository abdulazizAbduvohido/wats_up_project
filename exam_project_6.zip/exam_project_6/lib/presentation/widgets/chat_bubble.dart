import 'package:flutter/material.dart';
import '../../domain/entities/message_entity.dart';
import 'dart:io';

class ChatBubble extends StatelessWidget {
  final MessageEntity message;

  const ChatBubble({required this.message, super.key});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: message.isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 8.0),
        padding: message.imagePath != null ? EdgeInsets.zero : const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: message.isMine ? const Color(0xffdcf8c6) : Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (message.imagePath != null)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.insert_drive_file_outlined, color: Colors.blue),
                        const SizedBox(width: 8),
                        Text(
                          message.text!,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text('${message.size} ${message.timestamp.hour.toString().padLeft(2, '0')}:${message.timestamp.minute.toString().padLeft(2, '0')}',
                        style: const TextStyle(fontSize: 13)),
                  ],
                ),
              ),
            if (message.text != null && message.imagePath == null)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('${message.text}\n${message.timestamp.hour.toString().padLeft(2, '0')}:${message.timestamp.minute.toString().padLeft(2, '0')}',
                    style: const TextStyle(fontSize: 15)),
              ),
          ],
        ),
      ),
    );
  }
}