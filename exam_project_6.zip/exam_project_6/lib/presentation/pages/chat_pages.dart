
import 'package:exam_project_6/core/utils/websocket_channel.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../data/models/message.dart';
import '../widgets/chat_bubble.dart';
import '../widgets/message_input.dart';
import 'dart:io';
import 'contact_info_screen.dart'; 

class ChatScreen extends StatefulWidget {
  final String wsUrl;
  final String contactName;
  final String contactPhoto;

  const ChatScreen({
    required this.wsUrl,
    required this.contactName,
    required this.contactPhoto,
    super.key,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final WebSocketService _webSocketService;
  final TextEditingController _controller = TextEditingController();
  final List<MessageModel> _messages = [];
  String _connectionStatus = 'Ulanmoqda...';
  late String _currentContactName = widget.contactName;
  late String _currentContactPhoto = widget.contactPhoto;

  @override
  void initState() {
    super.initState();
    print('Boshlang‘ich rasm yo‘li: $_currentContactPhoto');
    _webSocketService = WebSocketService(widget.wsUrl);
    _webSocketService.stream.listen(
      (data) {
        print('Xom data: $data');
        if (data.toString().startsWith('Request served by')) return;
        setState(() {
          _connectionStatus = 'Ulandi';
          _messages.add(MessageModel(
            text: data.toString(),
            isMine: false,
            timestamp: DateTime.now(),
            imagePath: null,
            size: null,
          ));
          print('Xabarlar soni: ${_messages.length}');
        });
      },
      onError: (error) {
        setState(() {
          _connectionStatus = 'Xato: $error';
        });
      },
      onDone: () {
        setState(() {
          _connectionStatus = 'Ulanish uzildi';
        });
      },
    );
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _messages.add(MessageModel(
          text: 'IMG_${DateTime.now().millisecondsSinceEpoch}',
          isMine: true,
          timestamp: DateTime.now(),
          imagePath: pickedFile.path,
          size: '${(File(pickedFile.path).lengthSync() / (1024 * 1024)).toStringAsFixed(1)} MB • png',
        ));
        _webSocketService.send('IMG_${DateTime.now().millisecondsSinceEpoch}|${pickedFile.path}');
      });
    }
  }

  void _sendMessage() {
    if (_controller.text.trim().isEmpty) return;
    final msg = _controller.text.trim();
    _webSocketService.send(msg);
    setState(() {
      _messages.add(MessageModel(
        text: msg,
        isMine: true,
        timestamp: DateTime.now(),
        imagePath: null,
        size: null,
      ));
      print('Xabarlar soni: ${_messages.length}');
    });
    _controller.clear();
  }

  Future<void> _editContact() async {
    final TextEditingController _nameController = TextEditingController(text: _currentContactName);
    String? newPhoto = _currentContactPhoto;

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Contact'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  backgroundImage: AssetImage(_currentContactPhoto),
                  radius: 50,
                  onBackgroundImageError: (exception, stackTrace) {
                    print('Dialog rasmi yuklanmadi: $exception');
                  },
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Name'),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () async {
                    final picker = ImagePicker();
                    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
                    if (pickedFile != null) {
                      setState(() {
                        newPhoto = pickedFile.path;
                      });
                    }
                  },
                  child: const Text('Change Photo'),
                ),
                const SizedBox(height: 10),
                TextField(
                  decoration: const InputDecoration(labelText: 'Additional Info (e.g., phone)'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _currentContactName = _nameController.text;
                  if (newPhoto != null) _currentContactPhoto = newPhoto!;
                });
                Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  void _showContactInfo() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ContactInfoScreen(contactName: _currentContactName, contactPhoto: _currentContactPhoto),
      ),
    );
  }

  @override
  void dispose() {
    _webSocketService.close();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffece5dd),
      appBar: AppBar(
        backgroundColor: const Color(0xff075e54),
        title: InkWell(
          onTap: _showContactInfo, // Nomi yoki rasmga bosganda ContactInfoScreen ochiladi
          child: Row(
            children: [
              CircleAvatar(
                backgroundImage: AssetImage(_currentContactPhoto),
                radius: 20,
                onBackgroundImageError: (exception, stackTrace) {
                  print('AppBar rasmi yuklanmadi: $exception');
                },
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_currentContactName, style: const TextStyle(fontSize: 18)),
                  const Text('tap here for contact info', style: TextStyle(fontSize: 12)),
                ],
              ),
            ],
          ),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.video_call), onPressed: () {}),
          IconButton(icon: const Icon(Icons.call), onPressed: () {}),
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: _editContact,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('Ulanish holati: $_connectionStatus', style: const TextStyle(color: Colors.white)),
          ),
          Expanded(
            child: ListView.builder(
              reverse: true,
              padding: const EdgeInsets.all(10),
              itemCount: _messages.length,
              itemBuilder: (context, index) => ChatBubble(
                message: _messages[_messages.length - 1 - index],
              ),
            ),
          ),
          MessageInput(
            controller: _controller,
            onSend: _sendMessage,
            onPickImage: _pickImage,
          ),
        ],
      ),
    );
  }
}