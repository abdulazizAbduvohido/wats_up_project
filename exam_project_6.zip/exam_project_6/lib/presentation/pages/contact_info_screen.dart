import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class ContactInfoScreen extends StatelessWidget {
  final String contactName;
  final String contactPhoto;

  const ContactInfoScreen({Key? key, required this.contactName, required this.contactPhoto}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.blue),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          contactName,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 17,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(60),
                      image: DecorationImage(
                        image: AssetImage(contactPhoto), 
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    contactName,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildActionButton(
                        icon: Icons.message_outlined,
                        color: Colors.blue,
                        onTap: () {},
                      ),
                      _buildActionButton(
                        icon: Icons.videocam_outlined,
                        color: Colors.blue,
                        onTap: () {},
                      ),
                      _buildActionButton(
                        icon: Icons.phone_outlined,
                        color: Colors.blue,
                        onTap: () {},
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  // Quote
                  const Text(
                    'Design adds value faster, than it adds cost',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Dec 16, 2018',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  _buildMenuItem(
                    icon: Icons.folder_outlined,
                    iconColor: Colors.blue,
                    title: 'Media, Links, and Docs',
                    trailing: '12',
                  ),
                  _buildDivider(),
                  _buildMenuItem(
                    icon: Icons.star_outline,
                    iconColor: Colors.orange,
                    title: 'Starred Messages',
                    trailing: 'None',
                  ),
                  _buildDivider(),
                  _buildMenuItem(
                    icon: Icons.search,
                    iconColor: Colors.orange,
                    title: 'Chat Search',
                    trailing: '',
                  ),
                  _buildDivider(),
                  _buildMenuItem(
                    icon: Icons.volume_off_outlined,
                    iconColor: Colors.green,
                    title: 'Mute',
                    trailing: 'No',
                    hasSwitch: true,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(25),
        ),
        child: Icon(
          icon,
          color: color,
          size: 24,
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String trailing,
    bool hasSwitch = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Colors.black,
              ),
            ),
          ),
          if (hasSwitch)
            CupertinoSwitch(
              value: false,
              onChanged: (value) {},
              activeColor: Colors.green,
            )
          else if (trailing.isNotEmpty)
            Text(
              trailing,
              style: const TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
          const SizedBox(width: 8),
          const Icon(
            Icons.chevron_right,
            color: Colors.grey,
            size: 20,
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Container(
      margin: const EdgeInsets.only(left: 60),
      height: 0.5,
      color: Colors.grey[300],
    );
  }
}