import 'package:exam_project_6/presentation/pages/chat_pages.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  final List<Map<String, dynamic>> users = [
    {
      'name': 'Andrew Parker',
      'photo': 'assets/andrey.png',
      'lastMessage': 'What kind of strategy is better?',
      'time': '11/16/19',
    },
    {
      'name': 'Karen Castillo',
      'photo': 'assets/women.png',
      'lastMessage': '',
      'time': '11/15/19',
    },
    {
      'name': 'Maxim Jacob',
      'photo': 'assets/women.png',
      'lastMessage': 'Bro, I have a good idea!',
      'time': '10/30/19',
    },
    {
      'name': 'Martha Craig',
      'photo': 'assets/andrey.png',
      'lastMessage': 'Photo',
      'time': '10/28/19',
    },
    {
      'name': 'Tabitha Potter',
      'photo': 'assets/women.png',
      'lastMessage':
          'Actually I wanted to check with you about your online business plan on...',
      'time': '8/25/19',
    },
    {
      'name': 'Maisy Humph',
      'photo': 'assets/andrey.png',
      'lastMessage': 'Welcome, to make design faster, look at Pixsellz!',
      'time': '8/20/19',
    },
    {
      'name': 'Kieron Dodson',
      'photo': 'assets/women.png',
      'lastMessage': 'Ok, have a good trip!',
      'time': '7/28/19',
    },
  ];
  HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chats'),
        backgroundColor: const Color(0xff075e54),
      ),
      body: ListView.builder(
        itemCount: users.length,
        itemBuilder: (context, index) {
          final user = users[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: AssetImage(user['photo']),
              radius: 25,
            ),
            title: Text(user['name']),
            subtitle: Text(
              user['lastMessage'].isEmpty ? 'No messages' : user['lastMessage'],
            ),
            trailing: Text(user['time']),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChatScreen(
                    wsUrl: 'wss://echo.websocket.events',
                    contactName: user['name'],
                    contactPhoto: user['photo'],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
