import 'package:web_socket_channel/web_socket_channel.dart';

class WebSocketService {
  final WebSocketChannel _channel;

  WebSocketService(String url)
      : _channel = WebSocketChannel.connect(Uri.parse(url)) {
    print('WebSocket ulanishi boshlandi: $url');
  }

  Stream<dynamic> get stream {
    return _channel.stream.asBroadcastStream().map((data) {
      print('Serverdan xabar: $data');
      return data;
    }).handleError((error) {
      print('WebSocket xatosi: $error');
    });
  }

  void send(String message) {
    print('Yuborilgan xabar: $message');
    _channel.sink.add(message);
  }

  void close() {
    print('WebSocket yopildi');
    _channel.sink.close();
  }
}