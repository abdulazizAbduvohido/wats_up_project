class MessageEntity {
  final String? text;
  final String? imagePath;
  final String? size;
  final bool isMine;
  final DateTime timestamp;

  MessageEntity({
    this.text,
    this.imagePath,
    this.size,
    required this.isMine,
    required this.timestamp,
  });
}