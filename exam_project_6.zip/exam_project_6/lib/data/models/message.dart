import '../../domain/entities/message_entity.dart';

class MessageModel extends MessageEntity {
  MessageModel({
    String? text,
    String? imagePath,
    String? size,
    required bool isMine,
    required DateTime timestamp,
  }) : super(
          text: text,
          imagePath: imagePath,
          size: size,
          isMine: isMine,
          timestamp: timestamp,
        );
}